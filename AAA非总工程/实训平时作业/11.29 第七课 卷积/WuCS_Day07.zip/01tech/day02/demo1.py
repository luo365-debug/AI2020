name = input("输入姓名：")
age = input("输入年龄：")

print("姓名|年龄")
print("----|----")
print(name, age, sep="|")
