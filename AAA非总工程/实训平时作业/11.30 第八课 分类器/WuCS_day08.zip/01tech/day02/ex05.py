pass
# 注释
data = 200
data2 = data

print(data, 20, "hello",data2, True, sep="|", end="",flush=True)
name = input("输入：")
print(name)
