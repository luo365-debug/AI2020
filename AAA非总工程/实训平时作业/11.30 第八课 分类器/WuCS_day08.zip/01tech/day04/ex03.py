from uis.wapplication import WApplication

"""
app 与 dlg并列
"""

app = WApplication()
# dlg = WDialog()
# dlg.show()
app.exec()
