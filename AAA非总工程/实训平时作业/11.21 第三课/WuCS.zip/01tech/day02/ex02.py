#encoding:utf-8
print("Hello Python编程")
