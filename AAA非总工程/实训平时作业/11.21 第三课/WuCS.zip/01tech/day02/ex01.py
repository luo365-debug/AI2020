import mod01.ex02

print("Hello")
