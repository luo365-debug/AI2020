var = 23 + 145
if var < 100:
    print(var, 23 + 45)

for v in range(1,5):
    print(v)

#─━│┃╌╍╎╏┄┅┆┇┈┉┊┋┌┍┎┏┐┑┒┓└┕
print("┌────┐")
print("├────┤")
