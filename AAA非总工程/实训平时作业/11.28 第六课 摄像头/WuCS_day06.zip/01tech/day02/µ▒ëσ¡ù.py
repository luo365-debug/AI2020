print("汉字")
