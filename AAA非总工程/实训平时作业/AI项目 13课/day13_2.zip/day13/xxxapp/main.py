from xxxapp.guis.xxxapp import XXXApp

app = XXXApp()
app.exec()
