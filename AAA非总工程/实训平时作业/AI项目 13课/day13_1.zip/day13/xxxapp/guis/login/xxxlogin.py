from PyQt5.QtWidgets import QDialog

class XXXLogin(QDialog):

    def __init__(self):
        super(XXXLogin, self).__init__()