from PyQt5.QtWidgets import QDialog

"""
    Date:
    Function:
    Author:
    Comment:
    模块注释
        xxxxxxxxxxx
"""

class XXXHome(QDialog):
    """
        类注释
    """
    def __init__(self):
        """
            函数注释
        """
        super(XXXHome, self).__init__()
